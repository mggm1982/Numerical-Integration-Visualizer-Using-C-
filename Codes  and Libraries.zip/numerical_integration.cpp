#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

const double PI = acos(-1.0);

enum class FunctionType { Square = 1, Sine, Exponential, Cube, Cosine };
enum class Method { Midpoint = 1, Trapezoidal, Simpson };

double f(double x, FunctionType type) {
    switch (type) {
        case FunctionType::Square: return x * x;
        case FunctionType::Sine: return sin(x);
        case FunctionType::Exponential: return exp(x);
        case FunctionType::Cube: return x * x * x;
        case FunctionType::Cosine: return cos(x);
    }
    return numeric_limits<double>::quiet_NaN();
}

string functionName(FunctionType type) {
    switch (type) {
        case FunctionType::Square: return "x^2";
        case FunctionType::Sine: return "sin(x)";
        case FunctionType::Exponential: return "exp(x)";
        case FunctionType::Cube: return "x^3";
        case FunctionType::Cosine: return "cos(x)";
    }
    return "unknown";
}

double exactIntegral(double a, double b, FunctionType type) {
    switch (type) {
        case FunctionType::Square: return (b*b*b - a*a*a) / 3.0;
        case FunctionType::Sine: return cos(a) - cos(b);
        case FunctionType::Exponential: return exp(b) - exp(a);
        case FunctionType::Cube: return (pow(b,4) - pow(a,4)) / 4.0;
        case FunctionType::Cosine: return sin(b) - sin(a);
    }
    return numeric_limits<double>::quiet_NaN();
}

double midpointRule(double a, double b, int n, FunctionType type) {
    const double h = (b - a) / n;
    double sum = 0.0;
    for (int i = 0; i < n; ++i) {
        double xmid = a + (i + 0.5) * h;
        sum += f(xmid, type);
    }
    return h * sum;
}

double trapezoidalRule(double a, double b, int n, FunctionType type) {
    const double h = (b - a) / n;
    double sum = 0.5 * (f(a, type) + f(b, type));
    for (int i = 1; i < n; ++i) {
        sum += f(a + i * h, type);
    }
    return h * sum;
}

double simpsonRule(double a, double b, int n, FunctionType type) {
    if (n % 2 != 0) {
        throw invalid_argument("Simpson's 1/3 Rule requires an even number of intervals.");
    }
    const double h = (b - a) / n;
    double sum = f(a, type) + f(b, type);
    for (int i = 1; i < n; ++i) {
        sum += (i % 2 == 0 ? 2.0 : 4.0) * f(a + i * h, type);
    }
    return (h / 3.0) * sum;
}

double integrate(double a, double b, int n, FunctionType type, Method method) {
    switch (method) {
        case Method::Midpoint: return midpointRule(a, b, n, type);
        case Method::Trapezoidal: return trapezoidalRule(a, b, n, type);
        case Method::Simpson: return simpsonRule(a, b, n, type);
    }
    return numeric_limits<double>::quiet_NaN();
}

string methodName(Method method) {
    switch (method) {
        case Method::Midpoint: return "Midpoint Rectangle Rule";
        case Method::Trapezoidal: return "Trapezoidal Rule";
        case Method::Simpson: return "Simpson's 1/3 Rule";
    }
    return "Unknown";
}

void exportVisualizationCSV(double a, double b, int n, FunctionType type, Method method) {
    ofstream out("visualization.csv");
    out << "x,function_value,approximation_sample\n";
    out << setprecision(12);
    const int samples = max(200, n * 4);
    const double h = (b - a) / n;
    for (int i = 0; i <= samples; ++i) {
        double x = a + (b - a) * i / samples;
        double approx = numeric_limits<double>::quiet_NaN();
        if (method == Method::Midpoint) {
            int bin = min(n - 1, max(0, static_cast<int>((x - a) / h)));
            approx = f(a + (bin + 0.5) * h, type);
        } else if (method == Method::Trapezoidal) {
            int bin = min(n - 1, max(0, static_cast<int>((x - a) / h)));
            double x0 = a + bin * h;
            double x1 = x0 + h;
            double y0 = f(x0, type), y1 = f(x1, type);
            double t = (x - x0) / h;
            approx = y0 + t * (y1 - y0);
        } else {
            // The CSV records the function samples; Simpson's rule is a weighted sum,
            // not a unique piecewise curve. The approximation column is left blank.
            approx = numeric_limits<double>::quiet_NaN();
        }
        out << x << "," << f(x, type) << ",";
        if (isfinite(approx)) out << approx;
        out << "\n";
    }
}

void exportErrorAnalysisCSV(double a, double b, int maxN, FunctionType type) {
    ofstream out("error_analysis.csv");
    out << "intervals,midpoint_estimate,midpoint_abs_error,trapezoidal_estimate,trapezoidal_abs_error,simpson_estimate,simpson_abs_error\n";
    out << setprecision(12);
    const double exact = exactIntegral(a, b, type);
    int n = 2;
    int limit = max(256, maxN);
    while (n <= limit) {
        double m = midpointRule(a, b, n, type);
        double t = trapezoidalRule(a, b, n, type);
        double s = simpsonRule(a, b, n, type);
        out << n << "," << m << "," << fabs(m-exact) << ","
            << t << "," << fabs(t-exact) << ","
            << s << "," << fabs(s-exact) << "\n";
        if (n > limit / 2) break;
        n *= 2;
    }
}

int main() {
    cout << "===============================================\n";
    cout << " Numerical Integration Visualizer (C++17)\n";
    cout << "===============================================\n\n";
    cout << "Choose a function:\n"
         << "1. x^2\n2. sin(x)\n3. exp(x)\n4. x^3\n5. cos(x)\n";
    int fChoice;
    cout << "Function choice (1-5): ";
    if (!(cin >> fChoice) || fChoice < 1 || fChoice > 5) {
        cerr << "Invalid function choice.\n";
        return 1;
    }
    FunctionType type = static_cast<FunctionType>(fChoice);

    double a, b;
    int n;
    cout << "Lower limit a: ";
    if (!(cin >> a) || !isfinite(a)) {
        cerr << "Invalid lower limit.\n"; return 1;
    }
    cout << "Upper limit b: ";
    if (!(cin >> b) || !isfinite(b) || !(b > a)) {
        cerr << "Upper limit must be finite and greater than the lower limit.\n";
        return 1;
    }
    cout << "Number of intervals n (>=2): ";
    if (!(cin >> n) || n < 2 || n > 1000000) {
        cerr << "n must be an integer between 2 and 1,000,000.\n";
        return 1;
    }

    cout << "\nChoose a method:\n1. Midpoint Rectangle Rule\n2. Trapezoidal Rule\n3. Simpson's 1/3 Rule\n";
    int mChoice;
    cout << "Method choice (1-3): ";
    if (!(cin >> mChoice) || mChoice < 1 || mChoice > 3) {
        cerr << "Invalid method choice.\n"; return 1;
    }
    Method method = static_cast<Method>(mChoice);
    if (method == Method::Simpson && n % 2 != 0) {
        cerr << "Simpson's 1/3 Rule requires even n. Please rerun with even n.\n";
        return 1;
    }

    const double approx = integrate(a, b, n, type, method);
    const double exact = exactIntegral(a, b, type);
    const double absError = fabs(approx - exact);

    cout << "\n--------------- Results ----------------\n";
    cout << "Function: " << functionName(type) << "\n";
    cout << "Method: " << methodName(method) << "\n";
    cout << "Interval: [" << a << ", " << b << "]\n";
    cout << "Number of intervals: " << n << "\n";
    cout << setprecision(12) << fixed;
    cout << "Numerical estimate: " << approx << "\n";
    cout << "Exact integral:     " << exact << "\n";
    cout << "Absolute error:     " << absError << "\n";
    cout << "-----------------------------------------\n";

    exportVisualizationCSV(a, b, n, type, method);
    exportErrorAnalysisCSV(a, b, n, type);
    cout << "\nFiles created in the current folder:\n"
         << " - visualization.csv\n"
         << " - error_analysis.csv\n";
    cout << "\nNote: visualization.csv contains samples for plotting.\n"
         << "It does not itself create a shaded area plot; use Excel/Python\n"
         << "or another plotting tool to make graphs from the CSV files.\n";
    return 0;
}
